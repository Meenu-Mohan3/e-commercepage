function brown()
{
    var value = parseInt(document.getElementById('clr').value, 10);
   
	value='brown'
    document.getElementById('clr').value = value;
}
		
		function green()
{
    var value = parseInt(document.getElementById('clr').value, 10);
   
	value='green'
    document.getElementById('clr').value = value;
}

		function violet()
{
    var value = parseInt(document.getElementById('clr').value, 10);
   
	value='violet'
    document.getElementById('clr').value = value;
}
		function blue()
{
    var value = parseInt(document.getElementById('clr').value, 10);
   
	value='blue'
    document.getElementById('clr').value = value;
}
	

function xs()
{
    var value = parseInt(document.getElementById('size').value, 10);
   
	value='XS'
    document.getElementById('size').value = value;
}
		
		function  s()
{
    var value = parseInt(document.getElementById('size').value, 10);
   
	value='S'
    document.getElementById('size').value = value;
}

		function m()
{
    var value = parseInt(document.getElementById('size').value, 10);
   
	value='M'
    document.getElementById('size').value = value;
}
		function l()
{
    var value = parseInt(document.getElementById('size').value, 10);
   
	value='L'
    document.getElementById('size').value = value;
}

function xl()
{
    var value = parseInt(document.getElementById('size').value, 10);
   
	value='XL'
    document.getElementById('size').value = value;
}

function myfunction() {
    alert("The Product Has Been Added To Cart");
  }